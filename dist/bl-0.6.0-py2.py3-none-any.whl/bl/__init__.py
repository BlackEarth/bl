import os
JARS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'jars')